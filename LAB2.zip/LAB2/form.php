<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form Validation</title>
</head>

<body>
    <div class="phpcoding">
        <section class="headeroption">
            <h2>
                <?php
                echo "PHP form validation. ";
                ?>
            </h2>
        </section>
        <section class="maincontent">
        <hr />
        PHP Form Validation
        <hr/>
        <form method="post" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']) ?>">
            <table>
                <tr>
                    <td>Name </td>
                    <td> <input type="text" name="name" required >  </td>
               </tr>
                <tr>
                    <td>E-mail </td>
                    <td> <input type="text" name="email" required >  </td>
               </tr>
                <tr>
                    <td>Password </td>
                    <td> <input type="password" name="password" required >  </td>
               </tr>
                <tr>
                    <td>Gender </td>
                    <td>
                         <input type="radio"  name="gender" value="female"/> female
                           
                         <input type="radio"  name="gender" value="male"/> Male

                    </td>
               </tr>
                <tr>
                    <td>Comment </td>
                    <td> <textarea name="comment" id="" cols="40" rows="5"></textarea>  </td>
               </tr>
               <tr>
                <td></td>
                <td> <input type="submit" name="submit" value="submit"></td>
               </tr>
            </table>
        </form>
        <?php
            if ($_SERVER["REQUEST_METHOD"]== "POST") {
                $name = validate($_POST["name"]);
                $email = validate($_POST["email"]);
                $password = validate($_POST["password"]);
                $gender = validate($_POST["gender"]);
                $comment = validate($_POST["comment"]); 
                
             echo "Name : ".$name."<br/>";
             echo "E-mail : ".$email."<br/>";
             echo "Gender : ".$gender."<br/>";
             echo "Comment : ".$comment."<br/>";
                
            }

            function validate($data){   
                $data = trim($data);
                $data = stripcslashes($data);
                $data = htmlspecialchars($data);
                return $data;  
             }
             
            
            
        ?>





         </section>


    </div>

</body>

</html>