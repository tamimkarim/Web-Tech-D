<?php  
require_once 'controller/productInfo.php';

$product = fetchProduct($_GET['id']);


    include "nav.php";

?>

<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>

<table>
	<tr>
		<th>Name</th>
		<th>ID</th>
		<th>Buying Price</th>
		<th>Selling Price</th>
	</tr>
	<tr>
		<td><a href="showProduct.php?id=<?php echo $product['id'] ?>"><?php echo $product['name'] ?></a></td>
		<td><?php echo $product['name'] ?></td>
		<td><?php echo $product['id'] ?></td>
		<td><?php echo $product['byingprice'] ?></td>
		<td><?php echo $product['sellingprice'] ?></td>

		<!-- <td><img width="100px" src="uploads/< ?php echo $product['image'] ?>" alt="< ?php echo $product['name'] ?>"></td> -->
        
	</tr>

</table>


</body>
</html>