<?php  
require_once 'controller/productInfo.php';

$products = fetchAllProduct();


    include "nav.php";



?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>

<table>
	 <section style="align-items: center;">
		<h2>Display</h2>
		<tr>
			<th style="padding-right: 50px;">Name</th>
			<th style="padding-left: 10px;" >ID</th>
			<th style="padding-left: 10px;">Buying Price</th> <br>
			<th style="padding-left: 10px;">Selling Price </th>

		</tr>
	 </section>

		
	
	<tbody>
		<?php foreach ($products as $i => $product): ?>
			<tr>
				<td><a href="showProduct.php?id=<?php echo $product['id'] ?>"><?php echo $product['name'] ?></a></td>
				<!-- <td>< ?php echo $product['name'] ?></td> -->
				<td><?php echo $product['id'] ?></td>
				<td><?php echo $product['byingprice'] ?></td>
                <td><?php echo $product['sellingprice'] ?></td>


				<td><a href="editProduct.php?id=<?php echo $product['id'] ?>">Edit </a>&nbsp<a href="controller/deleteProduct.php?id=<?php echo $product['id'] ?>" onclick="return confirm('Are you sure want to delete this ?')">Delete</a></td>
			</tr>
		<?php endforeach; ?>
		

	</tbody>
	

</table>


</body>
</html>