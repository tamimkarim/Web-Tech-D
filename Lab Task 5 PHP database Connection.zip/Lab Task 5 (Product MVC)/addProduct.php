<!DOCTYPE html>
<html>
<head>
	<title></title>
    <link rel="stylesheet" href="/styles.css">
</head>
<body>
    <?php 
        include "nav.php";
     ?>
   

 <form action="controller/createProduct.php" method="POST" enctype="multipart/form-data">
  <label for="name">Name:</label><br>
  <input type="text" id="name" name="name"><br>
  <br>
  <label for="Buying Price">Buying Price:</label><br>
  <input type="text" id="byingprice" name="byingprice"><br>
  <br>
  <label for="Selling Price">Selling Price : </label><br>
  <input type="text" id="sellingprice" name="sellingprice"><br>
  <br>
  <label>
        <input type="checkbox" name="Display" id="your-checkbox-id">
        Display
  </label>
  <br>
        
  <input type="submit" name = "createProduct" value="Save">
   
</form> 

</body>
</html>

