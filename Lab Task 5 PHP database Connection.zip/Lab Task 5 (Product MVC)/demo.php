<!DOCTYPE html>
<html>
<head>
    <title>Checkbox Input Field</title>
</head>
<body>
    <h1>Checkbox Input Field</h1>
    <form>
        <!-- Replace 'your-checkbox-name' with a descriptive name for the checkbox -->
        <label>
            <input type="checkbox" name="Display" id="your-checkbox-id">
            Check this box
        </label>
        <br>
        <input type="submit" value="Submit">
    </form>
</body>
</html>
