<?php  
require_once '../model/model.php';


if (isset($_POST['updateProduct'])) {
	$data['name'] = $_POST['name'];
	$data['id'] = $_POST['id'];
	$data['byingprice'] = $_POST['byingprice'];
	$data['sellingprice'] = $_POST['sellingprice'];
	// $data['password'] = password_hash($_POST['password'], PASSWORD_BCRYPT, ["cost" => 12]);;
	// $data['image'] = basename($_FILES["image"]["name"]);

	// $target_dir = "../uploads/";
	// $target_file = $target_dir . basename($_FILES["image"]["name"]);


  if (updateProduct($_POST['id'], $data)) {
  	echo 'Successfully updated!!';
  	//redirect to showProduct
  	header('Location: ../showProduct.php?id=' . $_POST["id"]);
  }
} else {
	echo 'You are not allowed to access this page.';
}


?>