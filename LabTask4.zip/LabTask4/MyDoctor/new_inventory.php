<?php
    session_start();
    if(isset($_COOKIE['flag'])){
?>

<html lang="en">
<head>
<title>Document</title>
</head>
<body>
                    <td><select name="" id="">
                            <option value="">Air Conditions</option>
                            <option value="">Chair</option>
                            <option value="">Tables</option>
                            <option value="">Lights</option>
                            <option value="">Bedsheet</option>
                            <option value="">Bed</option>
                            <option value="">Wall Decor(paints,Sticker)</option>
                            <option value="">Fan</option><input type="text" name=""></input>

                        </select></td><br><br>
                                            <td><select name="" id="">
                            <option value="">Air Conditions</option>
                            <option value="">Chair</option>
                            <option value="">Tables</option>
                            <option value="">Lights</option>
                            <option value="">Bedsheet</option>
                            <option value="">Bed</option>
                            <option value="">Wall Decor(paints,Sticker)</option>
                            <option value="">Fan</option><input type="text" name=""></input>

                        </select></td><br><br>
                                            <td><select name="" id="">
                            <option value="">Air Conditions</option>
                            <option value="">Chair</option>
                            <option value="">Tables</option>
                            <option value="">Lights</option>
                            <option value="">Bedsheet</option>
                            <option value="">Bed</option>
                            <option value="">Wall Decor(paints,Sticker)</option>
                            <option value="">Fan</option><input type="text" name=""></input>

                        </select></td><br><br>
                                            <td><select name="" id="">
                            <option value="">Air Conditions</option>
                            <option value="">Chair</option>
                            <option value="">Tables</option>
                            <option value="">Lights</option>
                            <option value="">Bedsheet</option>
                            <option value="">Bed</option>
                            <option value="">Wall Decor(paints,Sticker)</option>
                            <option value="">Fan</option><input type="text" name=""></input>

                        </select></td><br><br>
                                            <td><select name="" id="">
                            <option value="">Air Conditions</option>
                            <option value="">Chair</option>
                            <option value="">Tables</option>
                            <option value="">Lights</option>
                            <option value="">Bedsheet</option>
                            <option value="">Bed</option>
                            <option value="">Wall Decor(paints,Sticker)</option>
                            <option value="">Fan</option><input type="text" name=""></input>

                        </select></td><br><br>
                                            <td><select name="" id="">
                            <option value="">Air Conditions</option>
                            <option value="">Chair</option>
                            <option value="">Tables</option>
                            <option value="">Lights</option>
                            <option value="">Bedsheet</option>
                            <option value="">Bed</option>
                            <option value="">Wall Decor(paints,Sticker)</option>
                            <option value="">Fan</option><input type="text" name=""></input>

                        </select></td><br><br>
                                            <td><select name="" id="">
                            <option value="">Air Conditions</option>
                            <option value="">Chair</option>
                            <option value="">Tables</option>
                            <option value="">Lights</option>
                            <option value="">Bedsheet</option>
                            <option value="">Bed</option>
                            <option value="">Wall Decor(paints,Sticker)</option>
                            <option value="">Fan</option><input type="text" name=""></input>

                       </select>
 <br><br>
                     <button><a href="order.php">Order</a></button>
                     <button><a href="Welcome.php"> Back </a></button>

                
</body>
</html>

<?php 
    }else{
        header('location: welcome.php'); 
    }
?>