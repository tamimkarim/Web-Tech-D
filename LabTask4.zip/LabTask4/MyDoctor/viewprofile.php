<?php
session_start();
require_once('registationcheckdata.php');
$name = $_SESSION['username'];
$user = getUserByname($name);
?>

<!DOCTYPE html>
<html>
<head>
    <title>MyDoctor - View Profile</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 600px;
            margin: 50px auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        h1 {
            text-align: center;
        }

        form {
            display: flex;
            flex-wrap: wrap;
        }

        label,
        input,
        textarea {
            width: 100%;
            margin-bottom: 10px;
        }

        label {
            font-weight: bold;
        }

        input,
        textarea {
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        input[type="submit"] {
            background-color: #4CAF50;
            color: #fff;
            cursor: pointer;
        }

        a {
            display: block;
            margin-top: 10px;
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>View Profile</h1>
        <form action="bar/top1.php" method="post">
            

            <label for="name">Name:</label>
            <input type="text" name="name" value="<?php echo $user[0] ?>" readonly>

            <label for="email">Email:</label>
            <input type="email" name="email" value="<?php echo $user[1] ?>" readonly>

            <label for="dob">Date of Birth:</label>
            <input type="date" name="dob" value="<?php echo $user[2] ?>" readonly>

            <label for="mobile">Mobile Number:</label>
            <input type="tel" name="mobile" value="<?php echo $user[3] ?>" readonly>

            <label for="gender">Gender:</label>
            <input type="text" name="gender" value="<?php echo $user[4] ?>" readonly>

            <label for="blood_group">Blood Group:</label>
            <input type="text" name="blood_group" value="<?php echo $user[5] ?>" readonly>

            <label for="division">Division:</label>
            <input type="text" name="division" value="<?php echo $user[6] ?>" readonly>

            <label for="city">City:</label>
            <input type="text" name="city" value="<?php echo $user[7] ?>" readonly>

            <label for="address">Address:</label>
            <textarea name="address" readonly><?php echo $user[8] ?></textarea>

            <label for="password">Password:</label>
            <input type="password" name="password" value="<?php echo $user[9] ?>" readonly>

            <label for="confirm_password">Confirm Password:</label>
            <input type="password" name="confirm_password" value="<?php echo $user[10] ?>" readonly>

            <a href="edit.php">Edit Profile  </a>
            
            <!-- <a href="Welcome.php">  Back</a> -->
        </form>
    </div>
</body>
</html>
