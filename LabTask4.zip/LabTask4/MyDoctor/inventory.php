<?php
    session_start();
    if(isset($_COOKIE['flag'])){
?>

<html lang="en">
<head>
<title>Document</title>
</head>
<body>
     
<div class="container" style="width:1200px;">              
<div class="table-responsive"> 
<table class="table table-bordered">  
<tr>    
<html lang="en">
<head>
    <title>Home Page</title>
</head>
<body>
        <h1>welcome ! <?=$_SESSION['username']?></h1>
        <h3><u>Inventory</u></h3>

        <table border="1">
            <tr>
                <th>Serial No.</th>
                <th>product ID</th>
                <th><BIIN id="1">Item</BIIN></th>
                <th>Product type</th>
                <th>Unit</th>
                <th>Quantity</th>
                <th>Reorder Quantity</th>
                <th>Cost</th>
            </tr>
        <?php 
            $dir = dirname(__FILE__);
            $file = fopen($dir . '/inventory.txt', 'r');
            $sr=1;

            while(!feof($file)){
                $data = fgets($file);
                $user = explode('|', $data);
                if(count($user) > 1){
        ?>
            <tr>
                <td><?=$sr?></td>
                <td><?=$user[0]?></td>
                <td><?=$user[1]?></td>
                <td><?=$user[2]?></td>
                <td><?=$user[3]?></td>
                <td><?=$user[4]?></td>
                <td><?=$user[5]?></td>
                <td><?=$user[6]?></td>
                
            </tr>

        <?php 
            }
            $sr++; 
        } ?>
        </table></br>
<button><a href="new_inventory.php">Add new Inventory</a></button>
 <button><a href="welcome.php"> Back </a></button>
</body>
</html>

<?php 
    }else{
        header('location: welcome.php'); 
    }
?>