<!DOCTYPE html>
<html>
<head>
    <title>Form Validation</title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }
        .container {
            max-width: 500px;
            margin: 0 auto;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        .form-group {
            margin-bottom: 15px;
        }
        .form-group label {
            display: block;
            font-weight: bold;
        }
        .form-group input[type="text"],
        .form-group input[type="password"] {
            width: 100%;
            padding: 8px;
            font-size: 16px;
            border: 1px solid #ccc;
            border-radius: 3px;
        }
        .form-group .error-message {
            color: #ff0000;
        }
        .form-group input[type="submit"] {
            background-color: cadetblue;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
    </style>
</head>
<body>
<?php

function validateUsername($username) {
    $pattern = '/^[a-zA-Z0-9.-_]{2,}$/';
    return preg_match($pattern, $username);
}


function validatePassword($password) {
    if (strlen($password) < 8) {
        return false;
    }

    $pattern = '/[@#$%]/';
    return preg_match($pattern, $password);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $userValid = validateUsername($username);
    $passValid = validatePassword($password);

    if (!$userValid || !$passValid) {
        
        $userError = $userValid ? '' : 'User Name must contain at least two (2) characters and can contain alpha-numeric characters, period, dash, or underscore only.';
        $passError = $passValid ? '' : 'Password must not be less than eight (8) characters and must contain at least one of the special characters (@, #, $, %).';

        echo '
            <div class="container">

                <h1>AIUB Login Page</h1> 
                <br>   
                <form method="post" action="">
                    <div class="form-group">
                        <label for="username">User Name:</label>
                        <input type="text" name="username" id="username" required>
                        <div class="error-message">' . $userError . '</div>
                    </div>
                    <div class="form-group">
                        <label for="password">Password:</label>
                        <input type="password" name="password" id="password" required>
                        <div class="error-message">' . $passError . '</div>
                    </div>
                    <div class="form-group">
                        <input type="submit" value="Submit">
                    </div>
                </form>
            </div>
        ';
    } else {
      
    }
} else {
    
    echo '
        <div class="container">
            <form method="post" action="">
                <div class="form-group">
                    <label for="username">User Name:</label>
                    <input type="text" name="username" id="username" required>
                </div>
                <div class="form-group">
                    <label for="password">Password:</label>
                    <input type="password" name="password" id="password" required>
                </div>
                <div class="form-group">
                    <input type="submit" value="Submit">
                </div>
            </form>
        </div>
    ';
}
?>
</body>
</html>
