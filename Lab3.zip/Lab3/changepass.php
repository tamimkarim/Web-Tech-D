<!DOCTYPE html>
<html>
<head>
  <title>Change Password</title>
  <style>
    body {
      font-family: Arial, sans-serif;
    }
    .form-container {
      max-width: 400px;
      margin: 0 auto;
      padding: 20px;
      border: 1px solid #ccc;
      border-radius: 5px;
    }
    .form-group {
      margin-bottom: 20px;
    }
    .form-group label {
      display: block;
      font-weight: bold;
      margin-bottom: 5px;
    }
    .form-group input {
      width: 100%;
      padding: 10px;
      border: 1px solid #ccc;
      border-radius: 3px;
    }
    .error {
      color: red;
      margin-top: 5px;
    }
  </style>
</head>
<body>
  <div class="form-container">
    <h2>Change Password</h2>
    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
      <div class="form-group">
        <label for="current_password">Current Password:</label>
        <input type="password" name="current_password" id="current_password" required>
      </div>
      <div class="form-group">
        <label for="new_password">New Password:</label>
        <input type="password" name="new_password" id="new_password" required>
      </div>
      <div class="form-group">
        <label for="retyped_password">Retype Password:</label>
        <input type="password" name="retyped_password" id="retyped_password" required>
      </div>
      <div class="form-group">
        <input type="submit" name="submit" value="Change Password">
      </div>
    </form>
    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
      $currPass = "abc@1234"; 
      $newPassword = $_POST["new_password"];
      $retypedPassword = $_POST["retyped_password"];
      $currentPassword = $_POST["current_password"];
      $errorMessages = [];

   
      if ($currentPassword !== $currPass) {
        $errorMessages[] = "Invalid current password.";
      }

      if ($newPassword === $currPass) {
        $errorMessages[] = "New password cannot be the same as the current password.";
      }

      if ($newPassword !== $retypedPassword) {
        $errorMessages[] = "New password and retyped password do not match.";
      }

      
      if (!empty($errorMessages)) {
        echo '<div class="error"><ul>';
        foreach ($errorMessages as $errorMessage) {
          echo "<li>$errorMessage</li>";
        }
        echo '</ul></div>';
      } else {
        
        echo '<div style="color: green;">Password changed successfully!</div>';
      }
    }
    ?>
  </div>
</body>
</html>
