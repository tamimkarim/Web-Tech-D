<!DOCTYPE html>
<html>
<head>
    <title>Picture Details</title>
</head>
<body>
    <h1>Upload Your pictures Here</h1>
    <form action="" method="post" enctype="multipart/form-data">
        <label for="picture">Select a picture:</label>
        <input type="file" id="picture" name="picture" accept=".jpeg, .jpg, .png" required>
        <button type="submit" name="upload">Upload</button>
    </form>

    <div id="errorDisplay">
        <?php
        if (isset($error)) {
            echo $error;
        }
        ?>
    </div>
</body>
</html>

<?php

if (isset($_POST['upload'])) {
    $allowedFormats = array('image/jpeg', 'image/jpg', 'image/png');
    $maxFileSize = 4 * 1024 * 1024;

    $pictureName = $_FILES['picture']['name'];
    $pictureType = $_FILES['picture']['type'];
    $pictureSize = $_FILES['picture']['size'];
    $pictureTmpName = $_FILES['picture']['tmp_name'];
    $pictureError = $_FILES['picture']['error'];

    if ($pictureError !== 0) {
        $error = "Error uploading the picture. Please try again.";
    } else {
        
        if (!in_array($pictureType, $allowedFormats)) {
            $error = "Picture format must be jpeg, jpg, or png.";
        } elseif ($pictureSize > $maxFileSize) {
            $error = "Picture size should not exceed 4MB.";
        } else {
            
            $uploadDir = 'uploads/';
            $uploadFilePath = $uploadDir . $pictureName;

            if (move_uploaded_file($pictureTmpName, $uploadFilePath)) {
                echo "Picture successfully uploaded.";
            } else {
                $error = "Error moving the uploaded picture.";
            }
        }
    }
}
?>
