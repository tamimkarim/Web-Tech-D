<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration Form</title>
</head>
<body>
    <?php
    $name = $email = $username = $password = $confirm_password = $gender = $dob = "";

    if ($_SERVER["REQUEST_METHOD"] === "POST") {
        $name = test_input($_POST["name"]);
        $email = test_input($_POST["email"]);
        $username = test_input($_POST["username"]);
        $password = test_input($_POST["password"]);
        $confirm_password = test_input($_POST["confirm_password"]);
        $gender = test_input($_POST["gender"]);
        $dob = test_input($_POST["dob"]);

        
        if ($password !== $confirm_password) {
            echo "Passwords do not match. Please try again.";
        } else {
           
            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                echo "Invalid email format. Please enter a valid email address.";
            } else {
                
                $data = [
                    "name" => $name,
                    "email" => $email,
                    "username" => $username,
                    "gender" => $gender,
                    "dob" => $dob
                ];

                
                $jsonData = json_encode($data);

               
                $file = fopen("data.json", "w");
                fwrite($file, $jsonData);
                fclose($file);

                
                header("Location: success.html");
                exit;
            }
        }
    }

    function test_input($data) {
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $data;
    }
    ?>

    <h2>Registration Form</h2>
    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
        <label for="name">Name:</label>
        <input type="text" name="name" id="name" required value="<?php echo $name; ?>"><br>

        <label for="email">Email:</label>
        <input type="email" name="email" id="email" required value="<?php echo $email; ?>"><br>

        <label for="username">Username:</label>
        <input type="text" name="username" id="username" required value="<?php echo $username; ?>"><br>

        <label for="password">Password:</label>
        <input type="password" name="password" id="password" required><br>

        <label for="confirm_password">Confirm Password:</label>
        <input type="password" name="confirm_password" id="confirm_password" required><br>

        <label>Gender:</label>
        <input type="radio" name="gender" value="male" required <?php echo ($gender === 'male') ? 'checked' : ''; ?>> Male
        <input type="radio" name="gender" value="female" required <?php echo ($gender === 'female') ? 'checked' : ''; ?>> Female
        <input type="radio" name="gender" value="other" required <?php echo ($gender === 'other') ? 'checked' : ''; ?>> Other<br>

        <label for="dob">Date of Birth:</label>
        <input type="date" name="dob" id="dob" required value="<?php echo $dob; ?>"><br>

        <input type="submit" name="submit" value="Submit">
        <input type="reset" value="Reset">
    </form>
</body>
</html>
